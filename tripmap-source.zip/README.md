# 旅迹 TripMap

电脑与手机通用的响应式旅行规划 PWA。默认带有 2026 年 7 月 25–29 日深圳、香港、广州示范行程，也可创建任意日期和城市的空白行程。

## 本地运行

```powershell
npm install
npm run dev
```

生产构建：

```powershell
npm run test
npm run build
npm run preview
```

不配置环境变量时，应用使用 OpenFreeMap、OpenStreetMap 免费搜索以及浏览器本地存储，所有核心规划功能都可使用。

## 可选的免费服务

复制 `.env.example` 为 `.env.local`：

```text
VITE_GEOAPIFY_KEY=你的免费Geoapify密钥
VITE_TRIP_API_URL=部署后的Supabase Edge Function地址
```

- Geoapify 密钥启用更稳定的中文地点搜索；免费计划需保留服务署名。
- `VITE_TRIP_API_URL` 为云端同步扩展接口地址。未配置时页脚明确显示“本地保存模式”。
- 不要在任何服务上开启自动付费或超额计费。

## 部署到 Cloudflare Pages

1. 将项目推送到 Git 仓库并在 Cloudflare Pages 导入。
2. 构建命令设为 `npm run build`，输出目录设为 `dist`。
3. 按需添加 `VITE_GEOAPIFY_KEY` 环境变量。
4. 部署完成后，在手机 Safari 或 Chrome 中打开网址，可通过浏览器菜单“添加到主屏幕”。

## 启用 Supabase 免费云同步

项目已包含数据库迁移和 Edge Function：

```powershell
npx supabase login
npx supabase link --project-ref 你的项目编号
npx supabase db push
npx supabase functions deploy trips --no-verify-jwt
```

将 Edge Function 地址（通常为 `https://项目编号.supabase.co/functions/v1/trips`）填写到 Cloudflare Pages 的 `VITE_TRIP_API_URL`，重新部署即可。数据表已开启 RLS 且无公开策略，只有 Edge Function 的服务角色能够访问；查看令牌与编辑令牌只以 SHA-256 哈希保存在数据库中。

启用后，“分享”会先创建云端副本并生成只读链接；编辑设备随后进行带版本号的自动保存，另一设备发生并发修改时返回冲突而不会静默覆盖。

## 已实现

- 电脑双栏、手机三标签响应式布局
- PWA 安装、静态缓存和最近行程离线快照
- 多地点地图、按天着色、每日时间轴
- 搜索、备选地点、跨日移动、鼠标和触摸排序
- 固定锚点、时间设置、冲突警告、路线估算
- 最近邻与 2-opt 一键优化
- 可视化总览、系统分享、打印/PDF 和 JSON 备份
- 只读链接界面模式、版本化本地保存

## 当前边界

免费无密钥模式使用估算路线，不提供 GPS 语音导航。跨境和城际段建议在地点备注中保存车次、口岸和时间。真正的跨设备云同步需要部署 Supabase 接口并配置 `VITE_TRIP_API_URL`。

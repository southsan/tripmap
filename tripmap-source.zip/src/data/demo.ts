import type { Place, PlaceKind, Trip, TripDay, Visit } from '../types'

const palette = ['#EF684A', '#5479E8', '#A465D8', '#E49B2E', '#2E9C78', '#D34E72', '#667085']

const spots: Array<[string, string, number, number, PlaceKind]> = [
  ['莲花山公园', '深圳市福田区红荔路6030号', 22.5543, 114.0646, 'attraction'],
  ['华强北步行街', '深圳市福田区华强北路', 22.5454, 114.0857, 'shopping'],
  ['东门老街', '深圳市罗湖区解放路', 22.5461, 114.1196, 'food'],
  ['香港西九龙站', '香港九龙佐敦西九龙站', 22.3048, 114.1615, 'transport'],
  ['M+博物馆', '香港九龙西九文化区博物馆道38号', 22.3001, 114.1591, 'attraction'],
  ['尖沙咀海滨花园', '香港九龙尖沙咀海旁', 22.2937, 114.1742, 'attraction'],
  ['庙街夜市', '香港九龙油麻地庙街', 22.3075, 114.1697, 'food'],
  ['中环街市', '香港中环皇后大道中93号', 22.2848, 114.1574, 'food'],
  ['中环至半山自动扶梯', '香港中环阁麟街', 22.2839, 114.1538, 'attraction'],
  ['太平山顶', '香港山顶山顶道118号', 22.2711, 114.1493, 'attraction'],
  ['香港西九龙站·出发', '香港九龙佐敦西九龙站', 22.3048, 114.1615, 'transport'],
  ['广州南站', '广州市番禺区石壁街道', 22.9907, 113.2690, 'transport'],
  ['陈家祠', '广州市荔湾区中山七路恩龙里34号', 23.1293, 113.2420, 'attraction'],
  ['永庆坊', '广州市荔湾区恩宁路99号', 23.1165, 113.2356, 'attraction'],
  ['沙面岛', '广州市荔湾区沙面南街', 23.1090, 113.2398, 'attraction'],
  ['越秀公园', '广州市越秀区解放北路988号', 23.1401, 113.2590, 'attraction'],
  ['北京路步行街', '广州市越秀区北京路', 23.1235, 113.2696, 'food'],
  ['广州塔', '广州市海珠区阅江西路222号', 23.1065, 113.3246, 'attraction']
]

const idFor = (name: string) => `p-${name.replaceAll(/[^\p{L}\p{N}]/gu, '-')}`

const places = Object.fromEntries(spots.map(([name, address, lat, lng, kind]) => {
  const id = idFor(name)
  return [id, { id, name, address, lat, lng, kind } satisfies Place]
}))

function visit(name: string, durationMinutes = 90, locked = false, notes = ''): Visit {
  return { id: crypto.randomUUID(), placeId: idFor(name), durationMinutes, locked, priority: 2, notes }
}

function day(index: number, date: string, city: string, visits: Visit[]): TripDay {
  return {
    id: crypto.randomUUID(), date, city, timezone: 'Asia/Shanghai', startTime: '09:30', endTime: '21:00',
    color: palette[index % palette.length], visits, legs: []
  }
}

export function createDemoTrip(): Trip {
  const days = [
    day(0, '2026-07-25', '深圳', [visit('莲花山公园', 90), visit('华强北步行街', 120), visit('东门老街', 120)]),
    day(1, '2026-07-26', '香港·九龙', [visit('香港西九龙站', 30, true, '抵达及入境'), visit('M+博物馆', 150), visit('尖沙咀海滨花园', 90), visit('庙街夜市', 120)]),
    day(2, '2026-07-27', '香港·港岛', [visit('中环街市', 75), visit('中环至半山自动扶梯', 60), visit('太平山顶', 150)]),
    day(3, '2026-07-28', '广州·荔湾', [visit('香港西九龙站·出发', 30, true, '高铁出发锚点'), visit('广州南站', 30, true, '抵达锚点'), visit('陈家祠', 90), visit('永庆坊', 120), visit('沙面岛', 90)]),
    day(4, '2026-07-29', '广州', [visit('越秀公园', 120), visit('北京路步行街', 120), visit('广州塔', 120)])
  ]
  const crossBorderFrom = days[3].visits[0], crossBorderTo = days[3].visits[1]
  days[3].legs = [{
    id: `${crossBorderFrom.id}-${crossBorderTo.id}`, fromVisitId: crossBorderFrom.id, toVisitId: crossBorderTo.id,
    mode: 'manual', distanceKm: 142, durationMinutes: 95, estimated: false, notes: '广深港高铁，预留出入境时间',
    geometry: [[114.1615, 22.3048], [113.2690, 22.9907]]
  }]
  return {
    id: crypto.randomUUID(), title: '大湾区五日漫游', startDate: '2026-07-25', endDate: '2026-07-29',
    version: 1, updatedAt: new Date().toISOString(), places, unscheduled: [],
    days
  }
}

export function createBlankTrip(title: string, startDate: string, endDate: string): Trip {
  const start = new Date(`${startDate}T00:00:00`)
  const end = new Date(`${endDate}T00:00:00`)
  const days: TripDay[] = []
  let cursor = new Date(start)
  let i = 0
  while (cursor <= end && i < 31) {
    days.push(day(i, cursor.toISOString().slice(0, 10), '待设置城市', []))
    cursor.setDate(cursor.getDate() + 1)
    i++
  }
  return { id: crypto.randomUUID(), title, startDate, endDate, version: 1, updatedAt: new Date().toISOString(), places: {}, unscheduled: [], days }
}

export const dayPalette = palette

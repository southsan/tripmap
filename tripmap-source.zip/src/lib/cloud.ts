import type { Trip } from '../types'

export interface CloudRef {
  id: string
  viewToken?: string
  editToken?: string
  activeToken?: string
  version: number
}

const apiUrl = (import.meta.env.VITE_TRIP_API_URL as string | undefined)?.replace(/\/$/, '')
export const cloudEnabled = Boolean(apiUrl)

async function request(path: string, init: RequestInit = {}) {
  if (!apiUrl) throw new Error('尚未配置云同步服务')
  const response = await fetch(`${apiUrl}${path}`, { ...init, headers: { 'Content-Type': 'application/json', ...(init.headers || {}) } })
  const data = await response.json().catch(() => ({}))
  if (!response.ok) {
    const error = new Error(data.error || '云同步失败') as Error & { status?: number }
    error.status = response.status
    throw error
  }
  return data
}

export async function createCloudTrip(document: Trip): Promise<CloudRef> {
  const data = await request('', { method: 'POST', body: JSON.stringify({ document }) })
  return { id: data.id, viewToken: data.viewToken, editToken: data.editToken, activeToken: data.editToken, version: data.version }
}

export async function loadCloudTrip(id: string, token: string): Promise<{ document: Trip; permission: 'view' | 'edit'; version: number }> {
  return request(`?id=${encodeURIComponent(id)}`, { headers: { Authorization: `Bearer ${token}` } })
}

export async function updateCloudTrip(ref: CloudRef, document: Trip): Promise<number> {
  const token = ref.editToken || ref.activeToken
  if (!token) throw new Error('没有编辑权限')
  const data = await request(`?id=${encodeURIComponent(ref.id)}`, { method: 'PATCH', headers: { Authorization: `Bearer ${token}` }, body: JSON.stringify({ document, expectedVersion: ref.version }) })
  return data.version
}

export async function rotateViewToken(ref: CloudRef) {
  const token = ref.editToken || ref.activeToken
  if (!token) throw new Error('没有编辑权限')
  return request(`?id=${encodeURIComponent(ref.id)}&action=rotate-view`, { method: 'POST', headers: { Authorization: `Bearer ${token}` } }) as Promise<{ viewToken: string }>
}

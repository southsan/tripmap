import { describe, expect, it } from 'vitest'
import type { Place, Trip, TripDay, Visit } from '../types'
import { buildTimeline, optimizeVisits, recalcDay, updatePlaceLocation } from './trip'

const places: Record<string, Place> = {
  a: { id: 'a', name: 'A', address: '', lat: 0, lng: 0, kind: 'other' },
  b: { id: 'b', name: 'B', address: '', lat: 0, lng: 3, kind: 'other' },
  c: { id: 'c', name: 'C', address: '', lat: 0, lng: 1, kind: 'other' },
  d: { id: 'd', name: 'D', address: '', lat: 0, lng: 2, kind: 'other' }
}
const visit = (id: string, locked = false): Visit => ({ id, placeId: id, durationMinutes: 60, locked })

describe('trip planning', () => {
  it('orders unlocked visits by a shorter path', () => {
    const optimized = optimizeVisits([visit('a'), visit('b'), visit('c'), visit('d')], places)
    expect(optimized.map(v => v.id)).toEqual(['a', 'c', 'd', 'b'])
  })

  it('keeps locked anchors in sequence', () => {
    const optimized = optimizeVisits([visit('a', true), visit('b'), visit('c'), visit('d', true)], places)
    expect(optimized[0].id).toBe('a')
    expect(optimized.at(-1)?.id).toBe('d')
  })

  it('builds legs and warns when a day runs late', () => {
    const day: TripDay = { id: 'day', date: '2026-07-25', city: '测试', timezone: 'Asia/Shanghai', startTime: '09:00', endTime: '10:30', color: '#000', visits: [visit('a'), visit('c')], legs: [] }
    const calculated = recalcDay(day, places)
    expect(calculated.legs).toHaveLength(1)
    expect(buildTimeline(calculated).at(-1)?.warning).toContain('超出结束时间')
  })

  it('rebuilds affected route geometry after a map marker moves', () => {
    const day = recalcDay({ id: 'day', date: '2026-07-25', city: '测试', timezone: 'Asia/Shanghai', startTime: '09:00', endTime: '18:00', color: '#000', visits: [visit('a'), visit('c')], legs: [] }, places)
    const trip: Trip = { id: 'trip', title: '测试', startDate: day.date, endDate: day.date, version: 1, updatedAt: '', places, unscheduled: [], days: [day] }
    const moved = updatePlaceLocation(trip, 'c', { lat: 0, lng: 4, address: '新地址' })
    expect(moved.places.c.address).toBe('新地址')
    expect(moved.days[0].legs[0].geometry?.at(-1)).toEqual([4, 0])
    expect(moved.days[0].legs[0].distanceKm).toBeGreaterThan(day.legs[0].distanceKm)
  })
})

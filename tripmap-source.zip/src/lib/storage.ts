import type { Leg, Place, SearchResult, TravelMode, Trip } from '../types'

const KEY = 'tripmap:current'

export function loadTrip(): Trip | null {
  try { return JSON.parse(localStorage.getItem(KEY) || 'null') }
  catch { return null }
}

export function saveTrip(trip: Trip) {
  localStorage.setItem(KEY, JSON.stringify(trip))
}

function inferKind(type = ''): SearchResult['kind'] {
  if (/hotel|hostel|guest/i.test(type)) return 'hotel'
  if (/restaurant|food|cafe/i.test(type)) return 'food'
  if (/station|airport|terminal/i.test(type)) return 'transport'
  if (/mall|shop|market/i.test(type)) return 'shopping'
  return 'attraction'
}

const hanPattern = /[\u3400-\u9fff]/

function uniqueParts(values: Array<string | undefined>) {
  return values.filter((value, index, list): value is string => Boolean(value) && list.indexOf(value) === index)
}

export function photonAddress(properties: Record<string, string | undefined>) {
  const administrative = [properties.state, properties.city, properties.district]
  const street = properties.street && properties.housenumber ? `${properties.street}${properties.housenumber}` : properties.street || properties.housenumber
  const locality = [...administrative, street].filter((value): value is string => Boolean(value))
  const hasChinese = locality.some(value => hanPattern.test(value))
  const allLocalityChinese = locality.length > 0 && locality.every(value => hanPattern.test(value))
  const values = hasChinese
    ? [...administrative, street, properties.country === '中国' ? undefined : properties.country]
    : [street, properties.district, properties.city, properties.state, properties.country]
  return uniqueParts(values).join(allLocalityChinese ? '' : ' · ')
}

export function localizedResultScore(result: Pick<SearchResult, 'name' | 'address'>) {
  return (hanPattern.test(result.name) ? 4 : 0) + (hanPattern.test(result.address) ? 2 : 0)
}

export function dedupeSearchResults(results: SearchResult[]) {
  const seen = new Set<string>()
  return results.filter(result => {
    const key = `${result.name.trim().toLocaleLowerCase()}|${result.address.trim().toLocaleLowerCase()}`
    if (seen.has(key)) return false
    seen.add(key)
    return true
  })
}

async function fetchJson(url: URL, signal?: AbortSignal, timeoutMs = 8000) {
  const controller = new AbortController()
  const timeout = window.setTimeout(() => controller.abort(new DOMException('搜索超时', 'TimeoutError')), timeoutMs)
  const abort = () => controller.abort(signal?.reason)
  signal?.addEventListener('abort', abort, { once: true })
  try {
    const response = await fetch(url, { signal: controller.signal, headers: { Accept: 'application/json' } })
    if (!response.ok) throw new Error(`地点服务返回 ${response.status}`)
    return await response.json()
  } finally {
    clearTimeout(timeout)
    signal?.removeEventListener('abort', abort)
  }
}

async function searchPhoton(query: string, signal?: AbortSignal): Promise<SearchResult[]> {
  const url = new URL('https://photon.komoot.io/api/')
  url.searchParams.set('q', query); url.searchParams.set('limit', '8')
  const data = await fetchJson(url, signal, 7000)
  const results = (data.features ?? []).map((feature: any) => {
    const properties = feature.properties ?? {}
    const [lng, lat] = feature.geometry.coordinates
    return {
      id: `photon-${properties.osm_type ?? 'place'}-${properties.osm_id ?? `${lat}-${lng}`}`,
      name: properties.name || properties.street || query,
      address: photonAddress(properties) || properties.name || query,
      lat: Number(lat), lng: Number(lng), kind: inferKind(properties.osm_value || properties.type)
    }
  }).filter((item: SearchResult) => Number.isFinite(item.lat) && Number.isFinite(item.lng))
    .sort((a: SearchResult, b: SearchResult) => localizedResultScore(b) - localizedResultScore(a))
  return dedupeSearchResults(results)
}

async function searchNominatim(query: string, signal?: AbortSignal): Promise<SearchResult[]> {
  const url = new URL('https://nominatim.openstreetmap.org/search')
  url.searchParams.set('q', query); url.searchParams.set('format', 'jsonv2'); url.searchParams.set('accept-language', 'zh-CN'); url.searchParams.set('limit', '6'); url.searchParams.set('addressdetails', '1')
  const data = await fetchJson(url, signal, 5000)
  return data.map((item: any) => ({ id: `nominatim-${item.place_id}`, name: item.name || item.display_name.split(',')[0], address: item.display_name, lat: Number(item.lat), lng: Number(item.lon), kind: inferKind(item.type) }))
}

export async function searchPlaces(query: string, signal?: AbortSignal): Promise<SearchResult[]> {
  const geoKey = import.meta.env.VITE_GEOAPIFY_KEY as string | undefined
  if (geoKey) {
    try {
      const url = new URL('https://api.geoapify.com/v1/geocode/search')
      url.searchParams.set('text', query); url.searchParams.set('lang', 'zh'); url.searchParams.set('limit', '6'); url.searchParams.set('apiKey', geoKey)
      const data = await fetchJson(url, signal, 7000)
      const results = data.features.map((f: any) => ({
        id: f.properties.place_id, name: f.properties.name || f.properties.formatted,
        address: f.properties.formatted, lat: f.properties.lat, lng: f.properties.lon,
        kind: inferKind(f.properties.result_type)
      }))
      if (results.length) return dedupeSearchResults(results)
    } catch (error) {
      if (signal?.aborted) throw error
    }
  }

  let photonResults: SearchResult[] = []
  try {
    photonResults = await searchPhoton(query, signal)
    // Photon is fast, but some Chinese places only contain English road fields.
    // Return immediately only when it already supplied a fully localized result;
    // otherwise let Nominatim contribute its zh-CN display names and addresses.
    if (photonResults.some(result => localizedResultScore(result) >= 6)) return photonResults
  } catch (error) {
    if (signal?.aborted) throw error
  }

  try {
    const nominatimResults = await searchNominatim(query, signal)
    const merged = dedupeSearchResults([...nominatimResults, ...photonResults])
      .sort((a, b) => localizedResultScore(b) - localizedResultScore(a))
    if (merged.length) return merged.slice(0, 8)
  } catch (error) {
    if (signal?.aborted) throw error
    if (photonResults.length) return photonResults
    throw new Error('地点搜索服务连接失败，请稍后重试或更换网络')
  }
  if (photonResults.length) return photonResults
  throw new Error('没有找到匹配地点，请尝试城市名加地点名')
}

export async function reverseGeocode(lat: number, lng: number, signal?: AbortSignal): Promise<SearchResult> {
  const fallback: SearchResult = {
    id: `coordinate-${lat.toFixed(6)}-${lng.toFixed(6)}`,
    name: '地图选点', address: `${lat.toFixed(6)}, ${lng.toFixed(6)}`,
    lat, lng, kind: 'other'
  }
  const geoKey = import.meta.env.VITE_GEOAPIFY_KEY as string | undefined
  if (geoKey) {
    try {
      const url = new URL('https://api.geoapify.com/v1/geocode/reverse')
      url.searchParams.set('lat', String(lat)); url.searchParams.set('lon', String(lng)); url.searchParams.set('lang', 'zh'); url.searchParams.set('apiKey', geoKey)
      const data = await fetchJson(url, signal, 7000)
      const properties = data.features?.[0]?.properties
      if (properties) return {
        id: properties.place_id || fallback.id,
        name: properties.name || properties.address_line1 || properties.formatted || fallback.name,
        address: properties.formatted || fallback.address,
        lat, lng, kind: inferKind(properties.result_type)
      }
    } catch (error) {
      if (signal?.aborted) throw error
    }
  }
  try {
    const url = new URL('https://photon.komoot.io/reverse')
    url.searchParams.set('lat', String(lat)); url.searchParams.set('lon', String(lng))
    const data = await fetchJson(url, signal, 7000)
    const candidates = (data.features ?? []).map((feature: any) => {
      const properties = feature.properties ?? {}
      return {
        id: `photon-${properties.osm_type ?? 'place'}-${properties.osm_id ?? fallback.id}`,
        name: properties.name || properties.street || fallback.name,
        address: photonAddress(properties) || fallback.address,
        lat, lng, kind: inferKind(properties.osm_value || properties.type)
      } satisfies SearchResult
    }).sort((a: SearchResult, b: SearchResult) => localizedResultScore(b) - localizedResultScore(a))
    return candidates[0] ?? fallback
  } catch (error) {
    if (signal?.aborted) throw error
    return fallback
  }
}

export async function fetchAccurateRoute(leg: Leg, from: Place, to: Place): Promise<Leg> {
  const geoKey = import.meta.env.VITE_GEOAPIFY_KEY as string | undefined
  if (!geoKey) throw new Error('配置免费 Geoapify 密钥后可刷新真实路线')
  if (leg.mode === 'manual') return leg
  const mode: Record<Exclude<TravelMode, 'manual'>, string> = { walk: 'walk', transit: 'transit', drive: 'drive', bicycle: 'bicycle' }
  const url = new URL('https://api.geoapify.com/v1/routing')
  url.searchParams.set('waypoints', `${from.lat},${from.lng}|${to.lat},${to.lng}`)
  url.searchParams.set('mode', mode[leg.mode]); url.searchParams.set('format', 'geojson'); url.searchParams.set('apiKey', geoKey)
  const response = await fetch(url)
  if (!response.ok) throw new Error('该路线暂时没有可用数据')
  const data = await response.json(), feature = data.features?.[0]
  if (!feature) throw new Error('该路线暂时没有可用数据')
  const coordinates = feature.geometry?.type === 'MultiLineString' ? feature.geometry.coordinates.flat() : feature.geometry.coordinates
  return { ...leg, distanceKm: feature.properties.distance / 1000, durationMinutes: Math.max(1, Math.round(feature.properties.time / 60)), geometry: coordinates, estimated: false }
}

export function exportTrip(trip: Trip) {
  const blob = new Blob([JSON.stringify(trip, null, 2)], { type: 'application/json' })
  const href = URL.createObjectURL(blob)
  const link = document.createElement('a'); link.href = href; link.download = `${trip.title}.tripmap.json`; link.click()
  URL.revokeObjectURL(href)
}

export async function importTrip(file: File): Promise<Trip> {
  const parsed = JSON.parse(await file.text()) as Trip
  if (!parsed?.title || !Array.isArray(parsed.days) || !parsed.places) throw new Error('这不是有效的 TripMap 备份文件')
  return parsed
}

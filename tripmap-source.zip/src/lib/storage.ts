import type { Leg, Place, SearchResult, TravelMode, Trip } from '../types'

const KEY = 'tripmap:current'

export function loadTrip(): Trip | null {
  try { return JSON.parse(localStorage.getItem(KEY) || 'null') }
  catch { return null }
}

export function saveTrip(trip: Trip) {
  localStorage.setItem(KEY, JSON.stringify(trip))
}

function inferKind(type = ''): SearchResult['kind'] {
  if (/hotel|hostel|guest/i.test(type)) return 'hotel'
  if (/restaurant|food|cafe/i.test(type)) return 'food'
  if (/station|airport|terminal/i.test(type)) return 'transport'
  if (/mall|shop|market/i.test(type)) return 'shopping'
  return 'attraction'
}

export async function searchPlaces(query: string, signal?: AbortSignal): Promise<SearchResult[]> {
  const geoKey = import.meta.env.VITE_GEOAPIFY_KEY as string | undefined
  if (geoKey) {
    const url = new URL('https://api.geoapify.com/v1/geocode/search')
    url.searchParams.set('text', query); url.searchParams.set('lang', 'zh'); url.searchParams.set('limit', '6'); url.searchParams.set('apiKey', geoKey)
    const response = await fetch(url, { signal })
    if (!response.ok) throw new Error('地点服务暂时不可用')
    const data = await response.json()
    return data.features.map((f: any) => ({
      id: f.properties.place_id, name: f.properties.name || f.properties.formatted,
      address: f.properties.formatted, lat: f.properties.lat, lng: f.properties.lon,
      kind: inferKind(f.properties.result_type)
    }))
  }
  const url = new URL('https://nominatim.openstreetmap.org/search')
  url.searchParams.set('q', query); url.searchParams.set('format', 'jsonv2'); url.searchParams.set('accept-language', 'zh-CN'); url.searchParams.set('limit', '6'); url.searchParams.set('addressdetails', '1')
  const response = await fetch(url, { signal, headers: { Accept: 'application/json' } })
  if (!response.ok) throw new Error('免费地点服务暂时不可用')
  const data = await response.json()
  return data.map((item: any) => ({ id: String(item.place_id), name: item.name || item.display_name.split(',')[0], address: item.display_name, lat: Number(item.lat), lng: Number(item.lon), kind: inferKind(item.type) }))
}

export async function fetchAccurateRoute(leg: Leg, from: Place, to: Place): Promise<Leg> {
  const geoKey = import.meta.env.VITE_GEOAPIFY_KEY as string | undefined
  if (!geoKey) throw new Error('配置免费 Geoapify 密钥后可刷新真实路线')
  if (leg.mode === 'manual') return leg
  const mode: Record<Exclude<TravelMode, 'manual'>, string> = { walk: 'walk', transit: 'transit', drive: 'drive', bicycle: 'bicycle' }
  const url = new URL('https://api.geoapify.com/v1/routing')
  url.searchParams.set('waypoints', `${from.lat},${from.lng}|${to.lat},${to.lng}`)
  url.searchParams.set('mode', mode[leg.mode]); url.searchParams.set('format', 'geojson'); url.searchParams.set('apiKey', geoKey)
  const response = await fetch(url)
  if (!response.ok) throw new Error('该路线暂时没有可用数据')
  const data = await response.json(), feature = data.features?.[0]
  if (!feature) throw new Error('该路线暂时没有可用数据')
  const coordinates = feature.geometry?.type === 'MultiLineString' ? feature.geometry.coordinates.flat() : feature.geometry.coordinates
  return { ...leg, distanceKm: feature.properties.distance / 1000, durationMinutes: Math.max(1, Math.round(feature.properties.time / 60)), geometry: coordinates, estimated: false }
}

export function exportTrip(trip: Trip) {
  const blob = new Blob([JSON.stringify(trip, null, 2)], { type: 'application/json' })
  const href = URL.createObjectURL(blob)
  const link = document.createElement('a'); link.href = href; link.download = `${trip.title}.tripmap.json`; link.click()
  URL.revokeObjectURL(href)
}

export async function importTrip(file: File): Promise<Trip> {
  const parsed = JSON.parse(await file.text()) as Trip
  if (!parsed?.title || !Array.isArray(parsed.days) || !parsed.places) throw new Error('这不是有效的 TripMap 备份文件')
  return parsed
}

import type { Leg, Place, TimelineItem, TravelMode, Trip, TripDay, Visit } from '../types'

export const modeLabels: Record<TravelMode, string> = {
  walk: '步行', transit: '公共交通', drive: '驾车', bicycle: '骑行', manual: '手动交通'
}

export function haversine(a: Place, b: Place) {
  const r = 6371
  const dLat = (b.lat - a.lat) * Math.PI / 180
  const dLng = (b.lng - a.lng) * Math.PI / 180
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * Math.PI / 180) * Math.cos(b.lat * Math.PI / 180) * Math.sin(dLng / 2) ** 2
  return 2 * r * Math.asin(Math.sqrt(x))
}

export function estimatedLeg(from: Visit, to: Visit, places: Record<string, Place>, mode: TravelMode = 'transit'): Leg {
  const distanceKm = haversine(places[from.placeId], places[to.placeId])
  const speed = { walk: 4.5, bicycle: 14, drive: 30, transit: 22, manual: 22 }[mode]
  const overhead = mode === 'transit' ? 12 : mode === 'drive' ? 5 : 0
  return {
    id: `${from.id}-${to.id}`, fromVisitId: from.id, toVisitId: to.id, mode,
    distanceKm, durationMinutes: Math.max(3, Math.round(distanceKm / speed * 60 + overhead)), estimated: true,
    geometry: [[places[from.placeId].lng, places[from.placeId].lat], [places[to.placeId].lng, places[to.placeId].lat]]
  }
}

export function recalcDay(day: TripDay, places: Record<string, Place>): TripDay {
  const previous = new Map(day.legs.map(leg => [`${leg.fromVisitId}-${leg.toVisitId}`, leg]))
  const legs = day.visits.slice(0, -1).map((visit, i) => {
    const to = day.visits[i + 1]
    return previous.get(`${visit.id}-${to.id}`) ?? estimatedLeg(visit, to, places)
  })
  return { ...day, legs }
}

function minutes(time: string) {
  const [h, m] = time.split(':').map(Number)
  return h * 60 + m
}

export function clock(value: number) {
  const normalized = ((value % 1440) + 1440) % 1440
  return `${String(Math.floor(normalized / 60)).padStart(2, '0')}:${String(normalized % 60).padStart(2, '0')}`
}

export function buildTimeline(day: TripDay): TimelineItem[] {
  let cursor = minutes(day.startTime)
  const endLimit = minutes(day.endTime)
  return day.visits.map((visit, i) => {
    const leg = i ? day.legs[i - 1] : undefined
    cursor += leg?.durationMinutes ?? 0
    if (visit.fixedTime) cursor = Math.max(cursor, minutes(visit.fixedTime))
    const start = cursor
    cursor += visit.durationMinutes
    const warning = cursor > endLimit ? `预计超出结束时间 ${cursor - endLimit} 分钟` : undefined
    return { visit, start: clock(start), end: clock(cursor), legBefore: leg, warning }
  })
}

function routeDistance(visits: Visit[], places: Record<string, Place>) {
  return visits.slice(0, -1).reduce((sum, item, i) => sum + haversine(places[item.placeId], places[visits[i + 1].placeId]), 0)
}

function optimizeBlock(block: Visit[], start: Visit | undefined, places: Record<string, Place>) {
  if (block.length < 2) return block
  const remaining = [...block]
  const ordered: Visit[] = []
  let current = start
  while (remaining.length) {
    const nextIndex = current ? remaining.reduce((best, candidate, index) =>
      haversine(places[current!.placeId], places[candidate.placeId]) < haversine(places[current!.placeId], places[remaining[best].placeId]) ? index : best, 0) : 0
    current = remaining.splice(nextIndex, 1)[0]
    ordered.push(current)
  }
  let best = ordered
  let bestDistance = routeDistance([...(start ? [start] : []), ...best], places)
  for (let i = 0; i < best.length - 1; i++) for (let j = i + 1; j < best.length; j++) {
    const candidate = [...best.slice(0, i), ...best.slice(i, j + 1).reverse(), ...best.slice(j + 1)]
    const distance = routeDistance([...(start ? [start] : []), ...candidate], places)
    if (distance < bestDistance) { best = candidate; bestDistance = distance }
  }
  return best
}

export function optimizeVisits(visits: Visit[], places: Record<string, Place>) {
  const result: Visit[] = []
  let block: Visit[] = []
  for (const visit of visits) {
    if (visit.locked || visit.fixedTime) {
      result.push(...optimizeBlock(block, result.at(-1), places), visit)
      block = []
    } else block.push(visit)
  }
  result.push(...optimizeBlock(block, result.at(-1), places))
  return result
}

export function normalizeTrip(trip: Trip): Trip {
  return { ...trip, days: trip.days.map(day => recalcDay(day, trip.places)), updatedAt: new Date().toISOString() }
}

export function updatePlaceLocation(trip: Trip, placeId: string, location: { lat: number; lng: number; address: string }): Trip {
  const place = trip.places[placeId]
  if (!place) return trip
  const places = { ...trip.places, [placeId]: { ...place, ...location } }
  const days = trip.days.map(day => day.visits.some(visit => visit.placeId === placeId)
    ? recalcDay({ ...day, legs: [] }, places)
    : day)
  return { ...trip, places, days }
}

export function dayStats(day: TripDay) {
  return {
    visits: day.visits.length,
    activityMinutes: day.visits.reduce((sum, v) => sum + v.durationMinutes, 0),
    travelMinutes: day.legs.reduce((sum, l) => sum + l.durationMinutes, 0),
    distanceKm: day.legs.reduce((sum, l) => sum + l.distanceKm, 0)
  }
}

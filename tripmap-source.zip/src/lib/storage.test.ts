import { describe, expect, it } from 'vitest'
import { dedupeSearchResults, localizedResultScore, photonAddress } from './storage'

describe('localized place formatting', () => {
  it('formats Chinese addresses in administrative-to-street order', () => {
    expect(photonAddress({
      state: '广东省', city: '深圳市', district: '南山区', street: '滨海大道', housenumber: '123号', country: '中国'
    })).toBe('广东省深圳市南山区滨海大道123号')
  })

  it('keeps readable separators for non-Chinese addresses', () => {
    expect(photonAddress({
      street: 'Binhai Boulevard', district: 'Shahe', city: 'Shenzhen', state: 'Guangdong Province', country: 'China'
    })).toBe('Binhai Boulevard · Shahe · Shenzhen · Guangdong Province · China')
  })

  it('keeps separators when provider data mixes Chinese and English parts', () => {
    expect(photonAddress({ state: '广东省', city: 'Shenzhen', district: 'Buji', country: '中国' }))
      .toBe('广东省 · Shenzhen · Buji')
  })

  it('ranks Chinese names and addresses ahead of English-only results', () => {
    const chinese = localizedResultScore({ name: '深圳湾公园', address: '广东省深圳市南山区滨海大道' })
    const mixed = localizedResultScore({ name: 'Shenzhen Bay Park', address: '广东省深圳市南山区' })
    const english = localizedResultScore({ name: 'Shenzhen Bay Park', address: 'Shenzhen · China' })
    expect(chinese).toBeGreaterThan(mixed)
    expect(mixed).toBeGreaterThan(english)
  })

  it('treats a Chinese name plus Chinese address as fully localized', () => {
    expect(localizedResultScore({ name: '深圳湾公园', address: '广东省深圳市南山区滨海大道' })).toBe(6)
    expect(localizedResultScore({ name: '深圳湾公园', address: 'Binhai Boulevard · Shenzhen' })).toBeLessThan(6)
  })

  it('removes duplicate provider results while keeping distinct entrances', () => {
    const base = { name: '深圳湾公园', address: '广东省深圳市南山区滨海大道', lat: 22.5, lng: 113.9, kind: 'attraction' as const }
    const results = dedupeSearchResults([
      { ...base, id: '1' },
      { ...base, id: '2' },
      { ...base, id: '3', address: `${base.address}辅路` }
    ])
    expect(results.map(result => result.id)).toEqual(['1', '3'])
  })
})

export type TravelMode = 'walk' | 'transit' | 'drive' | 'bicycle' | 'manual'
export type PlaceKind = 'attraction' | 'food' | 'hotel' | 'transport' | 'shopping' | 'other'

export interface Place {
  id: string
  providerId?: string
  name: string
  address: string
  lat: number
  lng: number
  kind: PlaceKind
}

export interface Visit {
  id: string
  placeId: string
  durationMinutes: number
  fixedTime?: string
  notes?: string
  locked?: boolean
  priority?: 1 | 2 | 3
}

export interface Leg {
  id: string
  fromVisitId: string
  toVisitId: string
  mode: TravelMode
  distanceKm: number
  durationMinutes: number
  geometry?: [number, number][]
  estimated: boolean
  notes?: string
}

export interface TripDay {
  id: string
  date: string
  city: string
  timezone: string
  startTime: string
  endTime: string
  notes?: string
  color: string
  visits: Visit[]
  legs: Leg[]
}

export interface Trip {
  id: string
  title: string
  startDate: string
  endDate: string
  version: number
  updatedAt: string
  places: Record<string, Place>
  unscheduled: Visit[]
  days: TripDay[]
}

export interface SearchResult {
  id: string
  name: string
  address: string
  lat: number
  lng: number
  kind: PlaceKind
}

export interface TimelineItem {
  visit: Visit
  start: string
  end: string
  legBefore?: Leg
  warning?: string
}

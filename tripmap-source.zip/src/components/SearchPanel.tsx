import { useEffect, useState } from 'react'
import { LoaderCircle, MapPin, Plus, Search, X } from 'lucide-react'
import type { SearchResult } from '../types'
import { searchPlaces } from '../lib/storage'

interface Props {
  dayLabel: string
  onAdd: (result: SearchResult, pending: boolean) => void
}

export function SearchPanel({ dayLabel, onAdd }: Props) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<SearchResult[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    if (query.trim().length < 2) { setResults([]); setError(''); return }
    const controller = new AbortController()
    const timer = window.setTimeout(async () => {
      setLoading(true); setError('')
      try { setResults(await searchPlaces(query.trim(), controller.signal)) }
      catch (e) { if ((e as Error).name !== 'AbortError') setError((e as Error).message) }
      finally { setLoading(false) }
    }, 450)
    return () => { clearTimeout(timer); controller.abort() }
  }, [query])

  return <div className="search-panel">
    <div className="search-input-wrap">
      <Search size={18} />
      <input value={query} onChange={e => setQuery(e.target.value)} placeholder="搜索景点、餐厅、车站…" aria-label="搜索地点" />
      {loading ? <LoaderCircle size={18} className="spin" /> : query && <button className="icon-btn tiny" onClick={() => setQuery('')} aria-label="清除"><X size={16} /></button>}
    </div>
    {(results.length > 0 || error) && <div className="search-results">
      {error && <p className="search-error">{error}。你仍可编辑示范地点。</p>}
      {results.map(result => <div className="search-result" key={result.id}>
        <MapPin size={18} />
        <div><strong>{result.name}</strong><span>{result.address}</span></div>
        <div className="result-actions">
          <button onClick={() => { onAdd(result, false); setQuery(''); setResults([]) }} title={`加入${dayLabel}`}><Plus size={16} />当天</button>
          <button onClick={() => { onAdd(result, true); setQuery(''); setResults([]) }} title="加入待安排">备选</button>
        </div>
      </div>)}
    </div>}
  </div>
}

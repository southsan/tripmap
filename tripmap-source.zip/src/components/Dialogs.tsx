import { useState } from 'react'
import { LockKeyhole, Trash2, Upload, X } from 'lucide-react'
import type { Place, TripDay, Visit } from '../types'
import { createBlankTrip } from '../data/demo'
import type { Trip } from '../types'

export function VisitDialog({ visit, place, days, currentDayId, onSave, onDelete, onClose }: {
  visit: Visit; place: Place; days: TripDay[]; currentDayId: string
  onSave: (visit: Visit, targetDay: string) => void; onDelete: () => void; onClose: () => void
}) {
  const [draft, setDraft] = useState(visit)
  const [targetDay, setTargetDay] = useState(currentDayId)
  return <div className="modal-backdrop" onMouseDown={onClose}><div className="modal-card" onMouseDown={e => e.stopPropagation()} role="dialog" aria-modal="true">
    <header><div><span className="eyebrow">地点设置</span><h2>{place.name}</h2></div><button className="icon-btn" onClick={onClose}><X /></button></header>
    <label>安排到<select value={targetDay} onChange={e => setTargetDay(e.target.value)}>{days.map(d => <option value={d.id} key={d.id}>{d.date} · {d.city}</option>)}</select></label>
    <div className="form-row"><label>停留时长（分钟）<input type="number" min="10" step="5" value={draft.durationMinutes} onChange={e => setDraft({ ...draft, durationMinutes: Math.max(10, Number(e.target.value)) })} /></label><label>固定到达时间<input type="time" value={draft.fixedTime || ''} onChange={e => setDraft({ ...draft, fixedTime: e.target.value || undefined })} /></label></div>
    <label>备注<textarea rows={3} value={draft.notes || ''} onChange={e => setDraft({ ...draft, notes: e.target.value })} placeholder="预约、门票、想吃的菜…" /></label>
    <button className={`lock-toggle${draft.locked ? ' active' : ''}`} onClick={() => setDraft({ ...draft, locked: !draft.locked })}><LockKeyhole size={17} />{draft.locked ? '已锁定：优化时保持位置' : '设为锚点'}</button>
    <footer><button className="danger-btn" onClick={onDelete}><Trash2 size={17} />删除地点</button><div><button className="secondary-btn" onClick={onClose}>取消</button><button className="primary-btn" onClick={() => onSave(draft, targetDay)}>保存</button></div></footer>
  </div></div>
}

export function DayDialog({ day, onSave, onClose }: { day: TripDay; onSave: (day: TripDay) => void; onClose: () => void }) {
  const [draft, setDraft] = useState(day)
  return <div className="modal-backdrop" onMouseDown={onClose}><div className="modal-card compact" onMouseDown={e => e.stopPropagation()}>
    <header><div><span className="eyebrow">每日设置</span><h2>{day.date}</h2></div><button className="icon-btn" onClick={onClose}><X /></button></header>
    <label>城市或区域<input value={draft.city} onChange={e => setDraft({ ...draft, city: e.target.value })} /></label>
    <div className="form-row"><label>开始时间<input type="time" value={draft.startTime} onChange={e => setDraft({ ...draft, startTime: e.target.value })} /></label><label>结束时间<input type="time" value={draft.endTime} onChange={e => setDraft({ ...draft, endTime: e.target.value })} /></label></div>
    <label>当天备注<textarea rows={3} value={draft.notes || ''} onChange={e => setDraft({ ...draft, notes: e.target.value })} /></label>
    <footer><span /><div><button className="secondary-btn" onClick={onClose}>取消</button><button className="primary-btn" onClick={() => onSave(draft)}>保存</button></div></footer>
  </div></div>
}

export function NewTripDialog({ onCreate, onDemo, onImport, onClose }: { onCreate: (trip: Trip) => void; onDemo: () => void; onImport: (file: File) => void; onClose: () => void }) {
  const [title, setTitle] = useState('我的新旅行')
  const [start, setStart] = useState(new Date().toISOString().slice(0, 10))
  const [end, setEnd] = useState(new Date(Date.now() + 4 * 86400000).toISOString().slice(0, 10))
  const valid = start <= end && (new Date(end).getTime() - new Date(start).getTime()) / 86400000 < 31
  return <div className="modal-backdrop" onMouseDown={onClose}><div className="modal-card compact" onMouseDown={e => e.stopPropagation()}>
    <header><div><span className="eyebrow">NEW TRIP</span><h2>创建一段新旅程</h2></div><button className="icon-btn" onClick={onClose}><X /></button></header>
    <label>行程名称<input value={title} onChange={e => setTitle(e.target.value)} /></label>
    <div className="form-row"><label>开始日期<input type="date" value={start} onChange={e => setStart(e.target.value)} /></label><label>结束日期<input type="date" value={end} onChange={e => setEnd(e.target.value)} /></label></div>
    {!valid && <p className="form-error">结束日期需晚于开始日期，且首版最多支持 31 天。</p>}
    <button className="demo-choice" onClick={onDemo}><strong>查看大湾区五日示例</strong><span>深圳 · 香港 · 广州，含 18 个示例地点</span></button>
    <label className="import-choice"><Upload size={17} /><span><strong>导入 TripMap 备份</strong><small>从电脑或手机选择 .json 文件</small></span><input type="file" accept=".json,.tripmap.json,application/json" onChange={e => e.target.files?.[0] && onImport(e.target.files[0])} /></label>
    <footer><span /><div><button className="secondary-btn" onClick={onClose}>取消</button><button className="primary-btn" disabled={!valid || !title.trim()} onClick={() => onCreate(createBlankTrip(title.trim(), start, end))}>创建空白行程</button></div></footer>
  </div></div>
}

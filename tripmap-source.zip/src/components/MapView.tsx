import { useEffect, useRef } from 'react'
import maplibregl, { Map, Marker } from 'maplibre-gl'
import 'maplibre-gl/dist/maplibre-gl.css'
import type { Trip } from '../types'

interface Props {
  trip: Trip
  selectedDayId: string | 'all'
  focusedPlaceId?: string
  onSelectPlace: (id: string) => void
}

export function MapView({ trip, selectedDayId, focusedPlaceId, onSelectPlace }: Props) {
  const container = useRef<HTMLDivElement>(null)
  const mapRef = useRef<Map | null>(null)
  const markers = useRef<Marker[]>([])

  useEffect(() => {
    if (!container.current || mapRef.current) return
    mapRef.current = new maplibregl.Map({
      container: container.current,
      style: 'https://tiles.openfreemap.org/styles/liberty',
      center: [113.85, 22.65], zoom: 7.2, attributionControl: false
    })
    mapRef.current.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'top-right')
    mapRef.current.addControl(new maplibregl.AttributionControl({ compact: true }), 'bottom-right')
    return () => { mapRef.current?.remove(); mapRef.current = null }
  }, [])

  useEffect(() => {
    if (!container.current) return
    const observer = new ResizeObserver(entries => {
      const entry = entries[0]
      if (!entry || entry.contentRect.width < 10 || entry.contentRect.height < 10) return
      const map = mapRef.current
      if (!map) return
      map.resize()
      const days = selectedDayId === 'all' ? trip.days : trip.days.filter(day => day.id === selectedDayId)
      const points = days.flatMap(day => day.visits.map(visit => trip.places[visit.placeId])).filter(Boolean)
      if (points.length) {
        const bounds = points.reduce((value, place) => value.extend([place.lng, place.lat]), new maplibregl.LngLatBounds())
        window.setTimeout(() => map.fitBounds(bounds, { padding: { top: 92, bottom: 100, left: 52, right: 52 }, maxZoom: 13, duration: 0 }), 30)
      }
    })
    observer.observe(container.current)
    return () => observer.disconnect()
  }, [trip, selectedDayId])

  useEffect(() => {
    const map = mapRef.current
    if (!map) return
    const render = () => {
      markers.current.forEach(marker => marker.remove())
      markers.current = []
      const days = selectedDayId === 'all' ? trip.days : trip.days.filter(day => day.id === selectedDayId)
      const bounds = new maplibregl.LngLatBounds()
      days.forEach(day => day.visits.forEach((visit, index) => {
        const place = trip.places[visit.placeId]
        if (!place) return
        const el = document.createElement('button')
        el.className = `map-pin${focusedPlaceId === place.id ? ' is-active' : ''}`
        el.style.setProperty('--pin-color', day.color)
        el.textContent = String(index + 1)
        el.title = place.name
        el.addEventListener('click', () => onSelectPlace(place.id))
        markers.current.push(new maplibregl.Marker({ element: el, anchor: 'bottom' }).setLngLat([place.lng, place.lat]).addTo(map))
        bounds.extend([place.lng, place.lat])
      }))
      trip.unscheduled.forEach(visit => {
        const place = trip.places[visit.placeId]
        if (!place || selectedDayId !== 'all') return
        const el = document.createElement('button'); el.className = 'map-pin is-pending'; el.textContent = '·'; el.title = place.name
        el.addEventListener('click', () => onSelectPlace(place.id))
        markers.current.push(new maplibregl.Marker({ element: el, anchor: 'bottom' }).setLngLat([place.lng, place.lat]).addTo(map))
        bounds.extend([place.lng, place.lat])
      })

      const features = days.flatMap(day => day.legs.map(leg => ({
        type: 'Feature' as const,
        properties: { color: day.color, estimated: leg.estimated ? 1 : 0 },
        geometry: { type: 'LineString' as const, coordinates: leg.geometry ?? [] }
      })).filter(feature => feature.geometry.coordinates.length > 1))
      const geojson = { type: 'FeatureCollection' as const, features }
      const source = map.getSource('routes') as maplibregl.GeoJSONSource | undefined
      if (source) source.setData(geojson)
      else {
        map.addSource('routes', { type: 'geojson', data: geojson })
        map.addLayer({ id: 'routes-shadow', type: 'line', source: 'routes', paint: { 'line-color': '#ffffff', 'line-width': 7, 'line-opacity': .85 } })
        map.addLayer({ id: 'routes', type: 'line', source: 'routes', paint: { 'line-color': ['get', 'color'], 'line-width': 4, 'line-opacity': .9, 'line-dasharray': [2, 1.2] } })
      }
      if (!bounds.isEmpty()) map.fitBounds(bounds, { padding: { top: 100, bottom: 110, left: 70, right: 70 }, maxZoom: 13, duration: 650 })
    }
    if (map.loaded()) render(); else map.once('load', render)
  }, [trip, selectedDayId, focusedPlaceId, onSelectPlace])

  useEffect(() => {
    const place = focusedPlaceId ? trip.places[focusedPlaceId] : undefined
    if (place) mapRef.current?.flyTo({ center: [place.lng, place.lat], zoom: 14, duration: 700 })
  }, [focusedPlaceId, trip.places])

  return <div ref={container} className="map-canvas" aria-label="行程地图" />
}

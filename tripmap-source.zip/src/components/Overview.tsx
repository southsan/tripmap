import { AlertTriangle, Clock3, MapPinned, Navigation, Printer, Share2 } from 'lucide-react'
import type { Trip } from '../types'
import { buildTimeline, dayStats } from '../lib/trip'

interface Props { trip: Trip; onShare: () => void }

function fmt(minutes: number) {
  if (minutes < 60) return `${minutes} 分钟`
  return `${Math.floor(minutes / 60)} 小时 ${minutes % 60 ? `${minutes % 60} 分` : ''}`
}

export function Overview({ trip, onShare }: Props) {
  const totalStops = trip.days.reduce((n, d) => n + d.visits.length, 0)
  const travel = trip.days.reduce((n, d) => n + dayStats(d).travelMinutes, 0)
  const distance = trip.days.reduce((n, d) => n + dayStats(d).distanceKm, 0)
  const warnings = trip.days.reduce((n, d) => n + buildTimeline(d).filter(x => x.warning).length, 0)
  return <div className="overview-page">
    <header className="overview-hero">
      <div><span className="eyebrow">TRIP OVERVIEW</span><h1>{trip.title}</h1><p>{trip.startDate} — {trip.endDate} · {trip.days.length} 天旅程</p></div>
      <div className="overview-actions"><button onClick={onShare}><Share2 size={17} />分享</button><button onClick={() => window.print()}><Printer size={17} />打印 / PDF</button></div>
    </header>
    <div className="stat-grid">
      <div><MapPinned /><span>地点</span><strong>{totalStops}</strong></div>
      <div><Clock3 /><span>预计交通</span><strong>{fmt(travel)}</strong></div>
      <div><Navigation /><span>路线长度</span><strong>{distance.toFixed(1)} km</strong></div>
      <div><AlertTriangle /><span>待处理提醒</span><strong>{warnings}</strong></div>
    </div>
    <div className="overview-days">
      {trip.days.map((day, dayIndex) => {
        const timeline = buildTimeline(day)
        return <section className="overview-day" key={day.id}>
          <div className="overview-day-index" style={{ background: day.color }}>DAY {dayIndex + 1}</div>
          <header><div><b>{day.city}</b><span>{day.date}</span></div><em>{day.startTime}–{day.endTime}</em></header>
          <div className="overview-stops">
            {timeline.map((item, index) => <div className="overview-stop" key={item.visit.id}>
              <span className="overview-dot" style={{ borderColor: day.color }}>{index + 1}</span>
              <div><time>{item.start}</time><strong>{trip.places[item.visit.placeId].name}</strong><small>{item.visit.durationMinutes} 分钟</small></div>
              {item.legBefore && <p>↳ {item.legBefore.durationMinutes} 分钟 · {item.legBefore.distanceKm.toFixed(1)} km</p>}
            </div>)}
            {!timeline.length && <p className="overview-empty">尚未安排地点</p>}
          </div>
        </section>
      })}
    </div>
  </div>
}

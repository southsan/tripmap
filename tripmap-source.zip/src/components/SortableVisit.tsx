import { useSortable } from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import { ChevronDown, ChevronUp, Clock3, GripVertical, LockKeyhole, MapPin, MoreHorizontal } from 'lucide-react'
import type { Place, TimelineItem } from '../types'

interface Props {
  item: TimelineItem
  place: Place
  dayId: string
  index: number
  color: string
  readonly?: boolean
  onFocus: () => void
  onEdit: () => void
  onMove: (direction: -1 | 1) => void
}

export function SortableVisit({ item, place, dayId, index, color, readonly, onFocus, onEdit, onMove }: Props) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: item.visit.id, data: { type: 'visit', dayId, visitId: item.visit.id }, disabled: readonly
  })
  return <div ref={setNodeRef} style={{ transform: CSS.Transform.toString(transform), transition, opacity: isDragging ? .45 : 1 }} className="visit-wrap">
    {item.legBefore && <div className="leg-row">
      <span className="leg-line" style={{ background: color }} />
      <span>{item.legBefore.mode === 'transit' ? '公共交通' : '路线'} · {item.legBefore.durationMinutes} 分钟 · {item.legBefore.distanceKm.toFixed(1)} km</span>
      {item.legBefore.estimated && <em>估算</em>}
    </div>}
    <article className="visit-card" onClick={onFocus}>
      <button className="drag-handle" {...attributes} {...listeners} aria-label="拖动调整顺序" disabled={readonly}><GripVertical size={19} /></button>
      <span className="visit-number" style={{ background: color }}>{index + 1}</span>
      <div className="visit-main">
        <div className="visit-title"><strong>{place.name}</strong>{item.visit.locked && <LockKeyhole size={14} />}</div>
        <div className="visit-meta"><Clock3 size={14} />{item.start}–{item.end}<span>·</span>{item.visit.durationMinutes} 分钟</div>
        <div className="visit-address"><MapPin size={13} />{place.address}</div>
        {item.warning && <div className="visit-warning">{item.warning}</div>}
      </div>
      {!readonly && <div className="visit-controls">
        <button onClick={e => { e.stopPropagation(); onMove(-1) }} disabled={index === 0} aria-label="上移"><ChevronUp size={17} /></button>
        <button onClick={e => { e.stopPropagation(); onMove(1) }} aria-label="下移"><ChevronDown size={17} /></button>
        <button onClick={e => { e.stopPropagation(); onEdit() }} aria-label="编辑"><MoreHorizontal size={18} /></button>
      </div>}
    </article>
  </div>
}

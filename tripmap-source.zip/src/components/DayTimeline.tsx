import { useDroppable } from '@dnd-kit/core'
import { SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable'
import { CalendarDays, RefreshCw, Route, Sparkles } from 'lucide-react'
import type { Place, TripDay, Visit } from '../types'
import { buildTimeline, dayStats } from '../lib/trip'
import { SortableVisit } from './SortableVisit'

interface Props {
  day: TripDay
  places: Record<string, Place>
  readonly?: boolean
  onOptimize: () => void
  onFocus: (placeId: string) => void
  onEdit: (visit: Visit) => void
  onMove: (visitId: string, direction: -1 | 1) => void
  onEditDay: () => void
  onRefreshRoutes: () => void
}

const weekday = (date: string) => new Intl.DateTimeFormat('zh-CN', { weekday: 'short' }).format(new Date(`${date}T12:00:00`))
const displayDate = (date: string) => new Intl.DateTimeFormat('zh-CN', { month: 'numeric', day: 'numeric' }).format(new Date(`${date}T12:00:00`))

export function DayTimeline({ day, places, readonly, onOptimize, onFocus, onEdit, onMove, onEditDay, onRefreshRoutes }: Props) {
  const { setNodeRef, isOver } = useDroppable({ id: `day-${day.id}`, data: { type: 'day', dayId: day.id } })
  const timeline = buildTimeline(day)
  const stats = dayStats(day)
  return <section ref={setNodeRef} className={`day-timeline${isOver ? ' is-over' : ''}`}>
    <header className="day-header">
      <div className="day-date" style={{ '--day-color': day.color } as React.CSSProperties}>
        <span>{displayDate(day.date)}</span><b>{weekday(day.date)}</b>
      </div>
      <div className="day-heading"><button onClick={onEditDay} disabled={readonly}><h2>{day.city}</h2></button><span>{day.startTime}–{day.endTime} · {stats.visits} 个地点</span></div>
      {!readonly && <button className="optimize-btn" onClick={onOptimize} disabled={day.visits.length < 3}><Sparkles size={16} />优化</button>}
    </header>
    <div className="day-summary"><Route size={15} /><span>交通约 {stats.travelMinutes} 分钟</span><span>·</span><span>{stats.distanceKm.toFixed(1)} km</span>{!readonly && <button className="route-refresh" onClick={onRefreshRoutes}><RefreshCw size={12} />刷新路线</button>}</div>
    <SortableContext items={day.visits.map(v => v.id)} strategy={verticalListSortingStrategy}>
      <div className="visit-list">
        {timeline.map((item, index) => <SortableVisit key={item.visit.id} item={item} place={places[item.visit.placeId]} dayId={day.id} index={index} color={day.color} readonly={readonly} onFocus={() => onFocus(item.visit.placeId)} onEdit={() => onEdit(item.visit)} onMove={d => onMove(item.visit.id, d)} />)}
        {!day.visits.length && <div className="empty-day"><CalendarDays size={25} /><strong>这一天还没有地点</strong><span>从上方搜索，或把备选地点拖到这里</span></div>}
      </div>
    </SortableContext>
  </section>
}

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { DndContext, DragEndEvent, PointerSensor, KeyboardSensor, useSensor, useSensors } from '@dnd-kit/core'
import { sortableKeyboardCoordinates } from '@dnd-kit/sortable'
import { CalendarRange, Check, Cloud, Download, FilePlus2, List, Map as MapIcon, MapPinned, Menu, PanelLeftClose, Share2, Sparkles, Upload, WifiOff, X } from 'lucide-react'
import type { SearchResult, Trip, TripDay, Visit } from './types'
import { createDemoTrip } from './data/demo'
import { normalizeTrip, optimizeVisits, recalcDay, updatePlaceLocation } from './lib/trip'
import { exportTrip, fetchAccurateRoute, importTrip, loadTrip, reverseGeocode, saveTrip } from './lib/storage'
import { cloudEnabled, createCloudTrip, loadCloudTrip, rotateViewToken, updateCloudTrip, type CloudRef } from './lib/cloud'
import { MapView } from './components/MapView'
import { SearchPanel } from './components/SearchPanel'
import { DayTimeline } from './components/DayTimeline'
import { DayDialog, MapPlaceDialog, NewTripDialog, VisitDialog } from './components/Dialogs'
import { Overview } from './components/Overview'

type MobileTab = 'plan' | 'map' | 'overview'
type Toast = { text: string; kind?: 'success' | 'warning' }

export default function App() {
  const [trip, setTrip] = useState<Trip>(() => normalizeTrip(loadTrip() ?? createDemoTrip()))
  const [selectedDayId, setSelectedDayId] = useState<string>(() => trip.days[0]?.id ?? '')
  const [mapFilter, setMapFilter] = useState<string | 'all'>('all')
  const [mobileTab, setMobileTab] = useState<MobileTab>('plan')
  const [focusedPlaceId, setFocusedPlaceId] = useState<string>()
  const [editing, setEditing] = useState<{ visit: Visit; dayId: string }>()
  const [editingDay, setEditingDay] = useState<TripDay>()
  const [newTripOpen, setNewTripOpen] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [mapPickMode, setMapPickMode] = useState(false)
  const [mapDraft, setMapDraft] = useState<SearchResult>()
  const [mapDraftResolving, setMapDraftResolving] = useState(false)
  const [toast, setToast] = useState<Toast>()
  const [online, setOnline] = useState(navigator.onLine)
  const [savedAt, setSavedAt] = useState(new Date())
  const [cloudRef, setCloudRef] = useState<CloudRef>()
  const [cloudStatus, setCloudStatus] = useState<'local' | 'loading' | 'saving' | 'saved' | 'conflict'>('local')
  const importInput = useRef<HTMLInputElement>(null)
  const pickReverseController = useRef<AbortController>()
  const moveReverseControllers = useRef(new Map<string, AbortController>())
  const readonly = new URLSearchParams(location.hash.replace('#', '')).get('mode') === 'view'
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 7 } }), useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }))

  const selectedDay = trip.days.find(day => day.id === selectedDayId) ?? trip.days[0]

  useEffect(() => {
    const timer = setTimeout(() => { saveTrip(trip); setSavedAt(new Date()) }, 250)
    return () => clearTimeout(timer)
  }, [trip])
  useEffect(() => {
    if (!cloudEnabled) return
    const params = new URLSearchParams(location.hash.replace('#', ''))
    const id = params.get('id'), token = params.get('token')
    if (!id || !token) return
    setCloudStatus('loading')
    loadCloudTrip(id, token).then(result => {
      const remote = normalizeTrip(result.document)
      setTrip(remote); setSelectedDayId(remote.days[0]?.id || '')
      setCloudRef({ id, activeToken: token, editToken: result.permission === 'edit' ? token : undefined, version: result.version })
      setCloudStatus('saved')
    }).catch(error => { setCloudStatus('conflict'); setToast({ text: error.message, kind: 'warning' }) })
  }, [])
  useEffect(() => {
    if (!cloudEnabled || !cloudRef?.editToken || readonly) return
    const timer = window.setTimeout(async () => {
      setCloudStatus('saving')
      try {
        const version = await updateCloudTrip(cloudRef, trip)
        setCloudRef(current => current ? { ...current, version } : current)
        setCloudStatus('saved')
      } catch (error) {
        const status = (error as Error & { status?: number }).status
        setCloudStatus(status === 409 ? 'conflict' : 'local')
        setToast({ text: (error as Error).message, kind: 'warning' })
      }
    }, 850)
    return () => clearTimeout(timer)
    // cloudRef changes after a successful save must not trigger another save.
  }, [trip, readonly])
  useEffect(() => {
    const onOnline = () => setOnline(true), onOffline = () => setOnline(false)
    addEventListener('online', onOnline); addEventListener('offline', onOffline)
    return () => { removeEventListener('online', onOnline); removeEventListener('offline', onOffline) }
  }, [])
  useEffect(() => { if (!toast) return; const t = setTimeout(() => setToast(undefined), 2600); return () => clearTimeout(t) }, [toast])
  useEffect(() => () => {
    pickReverseController.current?.abort()
    moveReverseControllers.current.forEach(controller => controller.abort())
  }, [])

  const commit = useCallback((mutator: (draft: Trip) => Trip) => {
    setTrip(current => normalizeTrip({ ...mutator(current), version: current.version + 1, updatedAt: new Date().toISOString() }))
  }, [])

  const addPlace = (result: SearchResult, pending: boolean) => {
    const placeId = `search-${result.id}`
    const visit: Visit = { id: crypto.randomUUID(), placeId, durationMinutes: 90, priority: 2 }
    commit(current => ({ ...current, places: { ...current.places, [placeId]: { ...result, id: placeId } }, unscheduled: pending ? [...current.unscheduled, visit] : current.unscheduled, days: pending ? current.days : current.days.map(day => day.id === selectedDay.id ? { ...day, visits: [...day.visits, visit] } : day) }))
    setToast({ text: pending ? '已加入待安排地点' : `已加入 ${selectedDay.city}`, kind: 'success' })
  }

  const pickMapLocation = useCallback(({ lat, lng }: { lat: number; lng: number }) => {
    setMapPickMode(false)
    const coordinateId = `coordinate-${lat.toFixed(6)}-${lng.toFixed(6)}`
    setMapDraft({ id: coordinateId, name: '地图选点', address: `${lat.toFixed(6)}, ${lng.toFixed(6)}`, lat, lng, kind: 'other' })
    setMapDraftResolving(true)
    pickReverseController.current?.abort()
    const controller = new AbortController()
    pickReverseController.current = controller
    reverseGeocode(lat, lng, controller.signal).then(result => {
      setMapDraft(current => current && Math.abs(current.lat - lat) < 1e-7 && Math.abs(current.lng - lng) < 1e-7 ? result : current)
    }).catch(error => {
      if ((error as Error).name !== 'AbortError') setToast({ text: '中文地址暂时无法解析，可手动填写', kind: 'warning' })
    }).finally(() => {
      if (pickReverseController.current === controller) setMapDraftResolving(false)
    })
  }, [])

  const saveMapPlace = (result: SearchResult, targetDayId: string) => {
    const placeId = `map-${crypto.randomUUID()}`
    const visit: Visit = { id: crypto.randomUUID(), placeId, durationMinutes: 90, priority: 2 }
    commit(current => ({
      ...current,
      places: { ...current.places, [placeId]: { ...result, id: placeId } },
      unscheduled: targetDayId === 'unscheduled' ? [...current.unscheduled, visit] : current.unscheduled,
      days: current.days.map(day => day.id === targetDayId ? { ...day, visits: [...day.visits, visit] } : day)
    }))
    setMapDraft(undefined); setFocusedPlaceId(placeId)
    if (targetDayId !== 'unscheduled') { setSelectedDayId(targetDayId); setMapFilter(targetDayId) }
    setToast({ text: targetDayId === 'unscheduled' ? '地图地点已加入待安排' : '地图地点已加入当天行程', kind: 'success' })
  }

  const moveMapPlace = useCallback((placeId: string, { lat, lng }: { lat: number; lng: number }) => {
    commit(current => {
      return updatePlaceLocation(current, placeId, { lat, lng, address: `${lat.toFixed(6)}, ${lng.toFixed(6)}` })
    })
    setFocusedPlaceId(placeId)
    setToast({ text: '地点已移动，路线已重新估算', kind: 'success' })
    moveReverseControllers.current.get(placeId)?.abort()
    const controller = new AbortController()
    moveReverseControllers.current.set(placeId, controller)
    reverseGeocode(lat, lng, controller.signal).then(result => {
      commit(current => {
        const place = current.places[placeId]
        if (!place || Math.abs(place.lat - lat) > 1e-7 || Math.abs(place.lng - lng) > 1e-7) return current
        return { ...current, places: { ...current.places, [placeId]: { ...place, address: result.address } } }
      })
    }).catch(() => undefined).finally(() => {
      if (moveReverseControllers.current.get(placeId) === controller) moveReverseControllers.current.delete(placeId)
    })
  }, [commit])

  const findVisit = (visitId: string) => {
    for (const day of trip.days) { const visit = day.visits.find(v => v.id === visitId); if (visit) return { visit, dayId: day.id } }
    const visit = trip.unscheduled.find(v => v.id === visitId); return visit ? { visit, dayId: 'unscheduled' } : undefined
  }

  const onDragEnd = ({ active, over }: DragEndEvent) => {
    if (!over || readonly) return
    const source = findVisit(String(active.id)); if (!source) return
    const overInfo = findVisit(String(over.id))
    const targetDayId = overInfo?.dayId ?? String(over.data.current?.dayId ?? '').replace('day-', '')
    if (!targetDayId || targetDayId === 'unscheduled') return
    commit(current => {
      const days = current.days.map(day => ({ ...day, visits: day.visits.filter(v => v.id !== source.visit.id) }))
      const target = days.find(day => day.id === targetDayId); if (!target) return current
      const overIndex = overInfo ? target.visits.findIndex(v => v.id === overInfo.visit.id) : target.visits.length
      target.visits.splice(overIndex < 0 ? target.visits.length : overIndex, 0, source.visit)
      return { ...current, days, unscheduled: current.unscheduled.filter(v => v.id !== source.visit.id) }
    })
  }

  const moveVisit = (dayId: string, visitId: string, direction: -1 | 1) => commit(current => ({ ...current, days: current.days.map(day => {
    if (day.id !== dayId) return day
    const visits = [...day.visits], index = visits.findIndex(v => v.id === visitId), target = index + direction
    if (index < 0 || target < 0 || target >= visits.length) return day
    ;[visits[index], visits[target]] = [visits[target], visits[index]]
    return { ...day, visits }
  }) }))

  const optimize = (day: TripDay) => {
    const before = day.visits.map(v => v.id).join(',')
    const optimized = optimizeVisits(day.visits, trip.places)
    if (before === optimized.map(v => v.id).join(',')) { setToast({ text: '当前顺序已经很顺路', kind: 'success' }); return }
    if (!confirm(`建议将「${day.city}」的未锁定地点重新排序。固定时间和锚点不会移动，是否应用？`)) return
    commit(current => ({ ...current, days: current.days.map(d => d.id === day.id ? { ...d, visits: optimized } : d) }))
    setToast({ text: '路线已优化，可继续手动调整', kind: 'success' })
  }

  const refreshRoutes = async (day: TripDay) => {
    if (!import.meta.env.VITE_GEOAPIFY_KEY) { setToast({ text: '配置免费 Geoapify 密钥后可刷新真实路线', kind: 'warning' }); return }
    setToast({ text: '正在刷新当天路线…' })
    try {
      const legs = await Promise.all(day.legs.map(leg => {
        const from = day.visits.find(v => v.id === leg.fromVisitId)!, to = day.visits.find(v => v.id === leg.toVisitId)!
        return fetchAccurateRoute(leg, trip.places[from.placeId], trip.places[to.placeId])
      }))
      commit(current => ({ ...current, days: current.days.map(d => d.id === day.id ? { ...d, legs } : d) }))
      setToast({ text: '路线已按地图数据更新', kind: 'success' })
    } catch (error) { setToast({ text: (error as Error).message, kind: 'warning' }) }
  }

  const saveVisit = (draft: Visit, targetDay: string) => {
    if (!editing) return
    commit(current => ({ ...current, days: current.days.map(day => ({ ...day, visits: day.id === targetDay ? [...day.visits.filter(v => v.id !== draft.id), draft] : day.visits.filter(v => v.id !== draft.id) })), unscheduled: current.unscheduled.filter(v => v.id !== draft.id) }))
    setEditing(undefined)
  }
  const deleteVisit = () => {
    if (!editing) return
    commit(current => ({ ...current, days: current.days.map(day => ({ ...day, visits: day.visits.filter(v => v.id !== editing.visit.id) })), unscheduled: current.unscheduled.filter(v => v.id !== editing.visit.id) }))
    setEditing(undefined)
  }

  const share = async () => {
    if (!cloudEnabled) {
      exportTrip(trip)
      setToast({ text: '尚未配置云同步，已导出可传给同行的行程备份', kind: 'warning' })
      return
    }
    try {
      let ref = cloudRef
      if (!ref) { ref = await createCloudTrip(trip); setCloudRef(ref); setCloudStatus('saved') }
      if (!ref.viewToken) {
        const rotated = await rotateViewToken(ref)
        ref = { ...ref, viewToken: rotated.viewToken }; setCloudRef(ref)
      }
      const url = `${location.origin}${location.pathname}#id=${encodeURIComponent(ref.id)}&token=${encodeURIComponent(ref.viewToken!)}&mode=view`
      if (navigator.share) await navigator.share({ title: trip.title, text: '查看我的旅行路线', url })
      else { await navigator.clipboard.writeText(url); setToast({ text: '只读链接已复制', kind: 'success' }) }
    } catch (error) { if ((error as Error).name !== 'AbortError') setToast({ text: (error as Error).message, kind: 'warning' }) }
  }

  const focusedVisit = editing ? trip.places[editing.visit.placeId] : undefined
  const dateLabel = useMemo(() => `${trip.startDate.slice(5).replace('-', '.')} — ${trip.endDate.slice(5).replace('-', '.')}`, [trip])

  const handleImport = async (file: File) => {
    try {
      const imported = normalizeTrip(await importTrip(file))
      setTrip(imported); setSelectedDayId(imported.days[0]?.id || ''); setNewTripOpen(false)
      setToast({ text: '行程备份已导入', kind: 'success' })
    } catch (error) { setToast({ text: (error as Error).message, kind: 'warning' }) }
  }

  const selectMapPlace = useCallback((id: string) => {
    setMapPickMode(false)
    setFocusedPlaceId(id)
    const hit = trip.days.flatMap(day => day.visits.map(visit => ({ day, visit }))).find(item => item.visit.placeId === id)
    if (hit) {
      setSelectedDayId(hit.day.id)
      if (innerWidth < 768) setMobileTab('plan')
    }
  }, [trip.days])

  return <div className={`app-shell${sidebarOpen ? '' : ' sidebar-collapsed'}`}>
    <header className="app-header">
      <div className="brand"><span className="brand-mark"><MapIcon size={21} /></span><div><b>旅迹</b><small>TRIPMAP</small></div></div>
      <div className="trip-title"><button className="icon-btn desktop-only" onClick={() => setSidebarOpen(v => !v)}><PanelLeftClose size={19} /></button><div><h1>{trip.title}</h1><span><CalendarRange size={13} />{dateLabel} · {trip.days.length} 天</span></div></div>
      <div className="header-status">{!online ? <span className="offline"><WifiOff size={14} />离线只读缓存</span> : cloudStatus === 'loading' || cloudStatus === 'saving' ? <span><Cloud size={14} />{cloudStatus === 'loading' ? '读取云端…' : '同步中…'}</span> : cloudStatus === 'conflict' ? <span className="offline">云端版本冲突</span> : <span><Check size={14} />{cloudStatus === 'saved' ? '云端已同步' : `已保存 ${savedAt.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })}`}</span>}</div>
      <div className="header-actions"><button className="secondary-btn desktop-only" onClick={share}><Share2 size={16} />分享</button><button className="primary-btn" onClick={() => setMobileTab('overview')}><Sparkles size={16} /><span className="desktop-only">行程总览</span></button><button className="icon-btn mobile-only" onClick={() => setNewTripOpen(true)}><Menu /></button></div>
    </header>

    <main className="workspace">
      <aside className={`planner-panel${mobileTab === 'plan' ? ' mobile-active' : ''}`}>
        <div className="planner-toolbar">
          {!readonly && <SearchPanel dayLabel={selectedDay?.city || '当天'} onAdd={addPlace} />}
          <div className="day-chips">
            {trip.days.map((day, i) => <button key={day.id} className={selectedDayId === day.id ? 'active' : ''} style={{ '--chip-color': day.color } as React.CSSProperties} onClick={() => { setSelectedDayId(day.id); setMapFilter(day.id) }}><small>D{i + 1}</small><span>{day.date.slice(5).replace('-', '/')}</span></button>)}
          </div>
        </div>
        {trip.unscheduled.length > 0 && <div className="pending-strip"><b>待安排 · {trip.unscheduled.length}</b><span>编辑地点即可选择日期</span>{trip.unscheduled.map(v => <button key={v.id} onClick={() => setEditing({ visit: v, dayId: selectedDay.id })}>{trip.places[v.placeId].name}</button>)}</div>}
        <div className="planner-scroll">
          <DndContext sensors={sensors} onDragEnd={onDragEnd}>
            {selectedDay && <DayTimeline day={selectedDay} places={trip.places} readonly={readonly} onOptimize={() => optimize(selectedDay)} onFocus={setFocusedPlaceId} onEdit={visit => setEditing({ visit, dayId: selectedDay.id })} onMove={(id, d) => moveVisit(selectedDay.id, id, d)} onEditDay={() => setEditingDay(selectedDay)} onRefreshRoutes={() => refreshRoutes(selectedDay)} />}
          </DndContext>
        </div>
      </aside>

      <section className={`map-panel${mobileTab === 'map' ? ' mobile-active' : ''}`}>
        <div className="map-filter"><button className={mapFilter === 'all' ? 'active' : ''} onClick={() => setMapFilter('all')}>全部路线</button>{trip.days.map((d, i) => <button key={d.id} className={mapFilter === d.id ? 'active' : ''} onClick={() => setMapFilter(d.id)}><i style={{ background: d.color }} />D{i + 1}</button>)}</div>
        {!readonly && <div className={`map-edit-tools${mapPickMode ? ' active' : ''}`}><button type="button" aria-pressed={mapPickMode} onClick={() => setMapPickMode(active => !active)}><MapPinned size={17} />{mapPickMode ? '取消选点' : '地图选点'}</button><span>{mapPickMode ? '点击地图放置地点' : '图钉可直接拖动'}</span></div>}
        <MapView trip={trip} selectedDayId={mapFilter} focusedPlaceId={focusedPlaceId} readonly={readonly} pickMode={mapPickMode} onSelectPlace={selectMapPlace} onPickLocation={pickMapLocation} onMovePlace={moveMapPlace} />
        <div className="map-legend"><b>路线说明</b><span><i className="solid" />行程路线</span><span><i className="dashed" />免费估算</span></div>
      </section>

      <section className={`overview-panel${mobileTab === 'overview' ? ' mobile-active' : ''}`}><Overview trip={trip} onShare={share} /></section>
    </main>

    <nav className="mobile-nav" aria-label="主导航">
      <button className={mobileTab === 'plan' ? 'active' : ''} onClick={() => setMobileTab('plan')}><List /><span>行程</span></button>
      <button className={mobileTab === 'map' ? 'active' : ''} onClick={() => setMobileTab('map')}><MapIcon /><span>地图</span></button>
      <button className={mobileTab === 'overview' ? 'active' : ''} onClick={() => setMobileTab('overview')}><Sparkles /><span>总览</span></button>
    </nav>

    {editing && focusedVisit && <VisitDialog visit={editing.visit} place={focusedVisit} days={trip.days} currentDayId={editing.dayId} onSave={saveVisit} onDelete={deleteVisit} onClose={() => setEditing(undefined)} />}
    {mapDraft && <MapPlaceDialog result={mapDraft} resolving={mapDraftResolving} days={trip.days} defaultDayId={selectedDay.id} onSave={saveMapPlace} onClose={() => { pickReverseController.current?.abort(); setMapDraft(undefined); setMapDraftResolving(false) }} />}
    {editingDay && <DayDialog day={editingDay} onSave={day => { commit(current => ({ ...current, days: current.days.map(d => d.id === day.id ? recalcDay(day, current.places) : d) })); setEditingDay(undefined) }} onClose={() => setEditingDay(undefined)} />}
    {newTripOpen && <NewTripDialog onCreate={newTrip => { setTrip(normalizeTrip(newTrip)); setSelectedDayId(newTrip.days[0].id); setNewTripOpen(false) }} onDemo={() => { const demo = normalizeTrip(createDemoTrip()); setTrip(demo); setSelectedDayId(demo.days[0].id); setNewTripOpen(false) }} onImport={handleImport} onClose={() => setNewTripOpen(false)} />}
    {toast && <div className={`toast ${toast.kind || ''}`}><Check size={18} />{toast.text}<button onClick={() => setToast(undefined)}><X size={15} /></button></div>}
    <div className="desktop-fab-menu">
      <button onClick={() => setNewTripOpen(true)}><FilePlus2 />新建行程</button>
      <button onClick={() => exportTrip(trip)}><Download />导出备份</button>
      <button onClick={() => importInput.current?.click()}><Upload />导入备份</button>
      <button onClick={() => cloudEnabled ? share() : setToast({ text: '按 README 配置 Supabase 后即可启用免费云同步', kind: 'warning' })}><Cloud />{cloudEnabled ? '云同步已连接' : '本地保存模式'}</button>
    </div>
    <input ref={importInput} className="file-input" type="file" accept=".json,.tripmap.json,application/json" onChange={e => e.target.files?.[0] && handleImport(e.target.files[0])} />
  </div>
}

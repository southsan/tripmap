import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'
import { viteSingleFile } from 'vite-plugin-singlefile'

const base = process.env.VITE_BASE_PATH || '/'
const singleFile = process.env.VITE_SINGLEFILE === '1'

export default defineConfig({
  base,
  plugins: [
    react(),
    ...(singleFile ? [viteSingleFile()] : [VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['icon.svg'],
      manifest: {
        name: '旅迹 TripMap',
        short_name: '旅迹',
        description: '电脑与手机通用的可视化旅行规划地图',
        theme_color: '#14231f',
        background_color: '#f6f3ea',
        display: 'standalone',
        orientation: 'any',
        start_url: base,
        lang: 'zh-CN',
        icons: [{ src: `${base}icon.svg`, sizes: 'any', type: 'image/svg+xml', purpose: 'any maskable' }]
      },
      workbox: {
        navigateFallback: '/index.html',
        runtimeCaching: [
          {
            urlPattern: /^https:\/\/tiles\.openfreemap\.org\//,
            handler: 'CacheFirst',
            options: { cacheName: 'tripmap-map', expiration: { maxEntries: 80, maxAgeSeconds: 604800 } }
          }
        ]
      }
    })])
  ]
})

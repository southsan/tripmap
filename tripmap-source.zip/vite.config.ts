import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { viteSingleFile } from 'vite-plugin-singlefile'

const base = process.env.VITE_BASE_PATH || '/'
const singleFile = process.env.VITE_SINGLEFILE === '1'

export default defineConfig({
  base,
  plugins: [
    react(),
    ...(singleFile ? [viteSingleFile()] : [])
  ]
})

create extension if not exists pgcrypto;

create table if not exists public.trip_docs (
  id uuid primary key default gen_random_uuid(),
  document jsonb not null,
  view_token_hash text not null,
  edit_token_hash text not null,
  version integer not null default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.trip_docs enable row level security;

-- No public policies: all access goes through the Edge Function using the service role.
create index if not exists trip_docs_updated_at_idx on public.trip_docs (updated_at desc);

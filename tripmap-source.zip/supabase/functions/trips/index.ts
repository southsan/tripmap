import { createClient } from 'npm:@supabase/supabase-js@2'

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, PATCH, OPTIONS'
}

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } })

function randomToken() {
  const bytes = crypto.getRandomValues(new Uint8Array(24))
  return btoa(String.fromCharCode(...bytes)).replaceAll('+', '-').replaceAll('/', '_').replaceAll('=', '')
}

async function hash(token: string) {
  const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(token))
  return [...new Uint8Array(bytes)].map(value => value.toString(16).padStart(2, '0')).join('')
}

Deno.serve(async request => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: cors })
  try {
    const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
    const url = new URL(request.url)
    const id = url.searchParams.get('id')

    if (request.method === 'POST' && !id) {
      const { document } = await request.json()
      if (!document || typeof document !== 'object') return json({ error: '缺少行程数据' }, 400)
      const viewToken = randomToken(), editToken = randomToken()
      const { data, error } = await supabase.from('trip_docs').insert({ document, view_token_hash: await hash(viewToken), edit_token_hash: await hash(editToken) }).select('id,version').single()
      if (error) throw error
      return json({ id: data.id, version: data.version, viewToken, editToken }, 201)
    }

    if (!id) return json({ error: '缺少行程 ID' }, 400)
    const token = request.headers.get('Authorization')?.replace(/^Bearer\s+/i, '')
    if (!token) return json({ error: '缺少访问令牌' }, 401)
    const { data: row, error } = await supabase.from('trip_docs').select('*').eq('id', id).single()
    if (error || !row) return json({ error: '行程不存在' }, 404)
    const tokenHash = await hash(token)
    const permission = tokenHash === row.edit_token_hash ? 'edit' : tokenHash === row.view_token_hash ? 'view' : null
    if (!permission) return json({ error: '链接无效或已失效' }, 403)

    if (request.method === 'GET') return json({ document: row.document, version: row.version, permission })

    if (request.method === 'POST' && url.searchParams.get('action') === 'rotate-view') {
      if (permission !== 'edit') return json({ error: '没有编辑权限' }, 403)
      const viewToken = randomToken()
      const { error: updateError } = await supabase.from('trip_docs').update({ view_token_hash: await hash(viewToken), updated_at: new Date().toISOString() }).eq('id', id)
      if (updateError) throw updateError
      return json({ viewToken })
    }

    if (request.method === 'PATCH') {
      if (permission !== 'edit') return json({ error: '没有编辑权限' }, 403)
      const { document, expectedVersion } = await request.json()
      if (!document || expectedVersion !== row.version) return json({ error: '行程已在另一台设备修改，请刷新后重试', currentVersion: row.version }, 409)
      const nextVersion = row.version + 1
      const { data, error: updateError } = await supabase.from('trip_docs').update({ document, version: nextVersion, updated_at: new Date().toISOString() }).eq('id', id).eq('version', row.version).select('version').maybeSingle()
      if (updateError) throw updateError
      if (!data) return json({ error: '行程已在另一台设备修改，请刷新后重试' }, 409)
      return json({ version: data.version })
    }
    return json({ error: '不支持的请求' }, 405)
  } catch (error) {
    console.error(error)
    return json({ error: '服务暂时不可用' }, 500)
  }
})
